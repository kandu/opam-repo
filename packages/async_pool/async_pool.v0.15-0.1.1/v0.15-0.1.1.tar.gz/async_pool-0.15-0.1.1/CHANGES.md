v0.15-0.1.1
-----------

* fix resource counting

v0.15-0.1.0
-----------

* simplify the api
* optional `idle_limit` parameter

v0.15-0.0.1
-----------

async\_pool instable release 
